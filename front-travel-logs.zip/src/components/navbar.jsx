
function Navbar() {

    return (
        <nav>
          <ul>
              <li> 
                  <a href="/">Home</a> 
              </li>
              <li> 
                  <a href="/">Categories</a>
              </li>
              <li>
                  <a href="/">Logs</a>
              </li>
              <li> 
                  <a href="/">List of travels</a>    
              </li>
          </ul>
        </nav>
    )
  }
  
  export default Navbar;